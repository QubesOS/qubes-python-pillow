.. Pillow (PIL fork) documentation master file, created by
   sphinx-quickstart on Fri Apr 12 19:51:26 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Pillow (PIL fork)'s documentation!
=============================================

Contents:

.. toctree::
   :maxdepth: 4

   PIL


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

