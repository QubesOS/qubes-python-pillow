from tester import *

from PIL import Image
from PIL import ImageShow

success()
